<?php die(); ?>
lang = O’zbekcha

Save = Saqlash
Remove = O’chirish
Confirm removal = O’chirish jarayonini tasdiqlang
Human code = Nazorat ko’di

Management = Boshqaruv
Password = Parol
keep authorization = eslab qolish
Enter = Kiring

Comments = Sharxlar
Comment = Izohlash

Meruert could not create system files; the root directory should be writeable = Tizim fayllarni yaratib bo'lmadi; root direktoriya yozuv uchun mavjud bo’lishi kerak.

Start = Boshlang`ich jarayon
Website name = Sayt nomini tanlang
Admin password = Administratorga maxfiy kalitni belgilang
Go = va ishlashni boshlang

Files = Fayllar
One level up = Yuqori darajaga
Root directory = Root direktoriya
Choose directory: = Papkani tanlash:
Open = Ochish
Upload: = Yuklash:
Add directory name if you need to add a directory in the current one and upload files there: = Agar papkani hozirgi ichgi qismiga qo’shish va unga fayllarni yuklash kerak bo'lsa, papka nomini kiriting:
one more file = yana bir fayl
Upload = Yuklash

Preferences = Sozlamalar
Website name: = Sayt nomi:
Admin password: = Administrator paroli:
allow comments = izohga yo’l qoyish
Send comment notifications to the following email: = Quyidagi e-mail po’chtaga izoh xabarnomasini yuborish:
Posts per page: = Yozuvlar beti:
Design theme: = Mavzu dizayni:
Interface language: = Til interfeysi:
secret blog = maxfiy blog

New post = Yangi yozuv
Edit post = Yozuvni taxrirlash
Title: = Sarlavha:
Post text: = Matn yozuvi:
Add new topic (or few comma divided): = Yangi mavzuni qo’shing (agar bir qancha bo’lsa, unda vergul orqali):
or choose from saved ones: = yoki mavjudini tanlang:
Base part of post URL address: = Yozish uchun manzil asosiy qismi:
Show additional options = Qo’shimcha yozuv o’ptsiyalarini ko’rsatish
Alternate text for TITLE tag: = Muqobil matn uchun TITLE:
SEO keywords: = Qidiruv sistemalari uchun kalit so’zlar:
SEO description: = Qidiruv sistemalari uchun tavsif:
store in drafts = hozircha chernovikda qoldirsh
use as page not in the blog = blogga joylashtirmaslik: oddiy sahifa qilish
link in the top menu = yo’llanma(ssilka) yuqoridagi menuda
link in the sidebar = yo’llanma(ssilka) yonbosh ustunchada
Post intro to be displayed in the blog instead of the text: = Lenta o’rnida ko’rsatiladigan matn:
Hide additional options = Qo’shimcha o’ptsiyalar yozuvlarini yashirish
Done = Tayyor.

: reply to a comment = : izohga javob
Reply to your comment: = Izohingizga javob:
Comment author: = Izoh muallifi:
E-mail of the comment author: = E-mail muallifi:
Website of the comment author: = Sayt muallifi:
Comment text: = Matn izohi:
Your reply: = Sizning javobingiz:
notify comment author about the reply = izoh muallifini javob xaqida xabardor qilish
just remove the comment = izohni o’chirish
: new comment = : yangi izoh
New comment at = Yangi izoh manzil bo’yicha:
: continuing discussion = : muhokamani davom ettirish

Drafts = Qora ro’yxatlar
Find = Izlash

January = yanvar
February = fevral
March = mart
April = aprel
May = may
June = iyun
July = iyul
August = avgust
September = sentabr
October = oktabr
November = noyabr
December = dekabr

Full text = To’liq matn
Edit = Tahrirlash
edit = ozg.

Your name: = Sizning ismingiz:
Your email (for notifications): = Sizning e-mailingiz (xabarnomalarni olish uchun):
Your website: = Sizning saytingiz:
Write a comment: = Izoh qoldiring:
Send = Yuborish

No posts here. = Ushbu bo'limda, hech narsa yo'q.
Pages: = Sahifalar:

Blog = Blog
Search = Izlash
Write = Yozish
Exit = Chiqish

Edit the comment = Izohni tahrirlash

Alternative main page: = Muqobil bosh sahifa:
Favourite = Tanlanganlar
in favourites = tanlanganlar sarasida

Edit the sidebar = Yonbosh ustuncha
Text before links: = Yo’llanmaga(ssilkaga) qadar matn:
Text after links: = Yo’llanmadan(ssilkagadan) keyingi matn:

Page suffix (e.g. .html): = Sahifani kengaytirish (musol uchun, .html):
Profile photo: = Sur’at:
remove photo = Sur’atni o’chirish

secret post = maxfiy yozuv
Secret posts = Maxfiy yozuvlar

Change publication date = Nashr sanasini o’zgartirish

hide Blog link = blog yollanmasini yashirish
hide Management link = boshqaruv yo’llanmasini yashirish
Powered by = Ishlayapti
Edit the top menu = Menyuni tahrirlash

Edit the footer = Erto’lani tahrirlash
Empty this field to reset the footer: = Andaza holatini tiklash uchun, bu maydoni bo’sh qoldiring:
do not use rich text editor = boy formatlash muharririni ishlatmaslik
Place Youtube / Google Maps / audio code here: = Youtube, Google Maps va musiqa xizmatlarini qo’shish uchun kodlar:

Read from the start = Boshidan o’qish
Usual blog order = Oddiy tartib yozuvlari
premoderate comments = izohlar sizning nazorat qilishingizni kutadi
Comments are premoderated. = Yangi izohlar tekshiruvni kutadi.
— to moderate = — ko’rib chiqilishi kutilmoqda
approve this comment = izohni tasdiqlash
use social buttons = ijtimoiy tugmalarni qo’shish

template = andoza
Edit the current template = Andozani tahrir qilish
HTML template: = HTML andoza:
Post / page template: = Andoza yozuvi yoki sahifalari:

raise updated posts = yangilangan yozuvlarni ko’tarish







Language switchers: = Til kalitlari:
topics in sidebar = yozuv mavzulari yonbosh ustunchada

Posts = Blog yozuvlari
Pages = Sahifalar

hide RSS link = RSS yo’llanmasini yashirish
hide Search link = qidiruv yo’llanmasini yashirish

Copying page = Sahifani ko’chirish
Copy this page = Ushbu sahifani ko’chirish

(edit part) = (qismni boshqarish)
(edit) = (ozg.)
Editing part = Qism tahriri
Insert stats code = Statistika ko’dini o’rnatish
stats code = Statistika ko’di

kB = KB

Remind password = Parolni eslatish
Your email: = Sizning e-mail:
Email = E-mail
Check your mailbox. = Elektron po’chtangizni tekshiring.
: password reminder = : parolni esga solish
Your password: = Sizning parolingiz:
Send notifications to the following email: = Quyidagi e-mailga xabarnomani yuborish:

allow comments for this entry = Ushbu yozuv uchun izohga ruxsat berish
make this entry visible for everyone = ushbu yozuvni barcha uchun ko’rinadigan qilish
closed website = yopiq sayt
Editing meta = Meta-ma’lumotlar
Alternative URL = Muqobil URL
Alternative heading = Muqobil sarlavha
Preface = So’zboshi
Alternative title = Muqobil TITLE
Keywords = Kalit so’zlar
Description = Tavsifi
Deferred post = Qoldirilgan yozuv
Create new folder = Yangi papka yaratish
display only content in the selected language = kontentni faqat tanlangan tilda aks ettirish
Post language: = Yozuv tili:
post ratings = yozuvlar reytingi
Ratings = Reytinglar

Create = Yaratish
create = yaratish
change = o’zgartirish
(edit menu) = (Menyuni tahrirlash)
Editing menu = Menyu tahriri
log = qaydnoma
Log = Qaydnoma





(edit PHP code) = (PHP-kodni tahrirlash)
PHP code = PHP-kod

Edit the super menu = Bosh menyu tahriri
only positive ratings = faqat ijobiy reytinglar
hide Favourite link = tanlangan yo’llanmasini yashirish
hide Secret posts link = maxfiy yozuvlar yo’llanmasini yashirish
hide Drafts link = qora ro’yxat yo’llanmasini yashirish
hide Files link = fayllar yo’llanmasini yashirish
hide Comments link = izohlar yo’llanmasini yashirish
hide Ratings link = reytinglar yo’llanmasini yashirish

hide topic list = mavzular ro’yxatini yashirish

Create new file = Yangi fayl yaratish
MB = MB

Publish in = Nashr joyi
main blog = asosiy blog
add a blog = blog qo’shish
New blog title = Yangi blogning nomi
blogs in sidebar = Yon panel bloglar nomi
blogs = bloglar
topics = yozuvlar mavzusi
Name = Nomi
search in sidebar = yonbosh ustunchada izlash

edit Meta = Meta-teglar
Edit Meta = Meta-teglar
Motto: = Shior:
Confirm, please! = Iltimos, tasdiqlang!
Reset the preferences = Sozlamalarni tashlash

Nickname / name: = Ism yoki Nik:
E-mail: = Elektron manzil:
Message: = Xabar:
Message from your website = Sizning saytingizdan xabar
Message sent. = Xabar yuborildi.

Cancel = Bekor qilish
make main page = Bosh sahifa qilish

Click to enlarge = Kattalashtirish uchun bosing

Record order: = Yozuv tartibi:
usual = oddiy
from beginning = vaqt boshidan beri
random = tasodifiy
alphabetical = alifboga oid
anti-alphabetical = alifboga zid
by rating = reyting bo’yicha

Pagination: = Sahifa tartib raqami:
under the posts = yozuvlar tagida
over and under the posts = Yuqori va pastki yozuvlarda
concise = ixcham
none = mavjud emas
previous = avvalgi
next = keyingi
